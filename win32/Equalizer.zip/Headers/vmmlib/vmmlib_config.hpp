#ifndef __VMML__VMMLIB_CONFIG__HPP__
#define __VMML__VMMLIB_CONFIG__HPP__

// #define VMMLIB_NO_SFINAE 

#ifndef VMMLIB_CUSTOM_CONFIG

    #ifndef NDEBUG
        #define VMMLIB_SAFE_ACCESSORS
    #endif

    #define VMMLIB_THROW_EXCEPTIONS

#endif

#endif

