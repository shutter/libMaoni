#ifndef __VMML__LAPACK_INCLUDES__HPP__
#define __VMML__LAPACK_INCLUDES__HPP__


#ifdef __APPLE__

#include <Accelerate/Accelerate.h>

#else

// FIXME - include clapack headers

#endif



#endif

